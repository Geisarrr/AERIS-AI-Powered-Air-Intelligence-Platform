# AERIS ISPU Resume Fetcher

`ispu_resume.py` hanya mengambil tanggal yang belum ada pada data ISPU lokal/ZIP.

## Coverage pada ispu.zip yang diperiksa

- Jakarta Pusat: 2024 lengkap, 2025 lengkap, 2026-01-01 s.d. 2026-09-03 lengkap
- Jakarta Selatan: 2024 lengkap, 2025 lengkap, 2026-01-01 s.d. 2026-09-03 lengkap
- Jakarta Barat: 2024 lengkap
- Jakarta Barat 2025-2026: belum tersimpan di ZIP
- Jakarta Timur 2024-2026: belum tersimpan di ZIP
- Jakarta Utara 2024-2026: belum tersimpan di ZIP

Untuk periode 2024-01-01 s.d. 2026-09-03:
- total station-days: 4,885
- sudah ada di ZIP: 2,320
- pending: 2,565

## Instalasi

Simpan:

```text
pipeline/fetch/ispu_resume.py
```

Simpan `ispu.zip` di root repository, atau gunakan path lain pada `--existing-zip`.

Dependency tetap sama:

```bash
pip install requests polars beautifulsoup4
```

## Cek rencana tanpa fetching

```bash
python pipeline/fetch/ispu_resume.py \
  --existing-zip ispu.zip \
  --end-date 2026-09-03 \
  --dry-run
```

`--dry-run` tidak melakukan HTTP request. Data dari ZIP akan di-merge ke `data/raw/ispu` agar planner dapat menghitung tanggal yang sudah ada.

## Jalankan resume

```bash
python pipeline/fetch/ispu_resume.py \
  --existing-zip ispu.zip \
  --progress-every 10 \
  --checkpoint-size 25
```

Untuk mencegah idle sleep di macOS:

```bash
caffeinate -i python pipeline/fetch/ispu_resume.py \
  --existing-zip ispu.zip \
  --progress-every 10 \
  --checkpoint-size 25
```

## Setelah ZIP sudah diimport

Run berikutnya tidak wajib memakai `--existing-zip`:

```bash
python pipeline/fetch/ispu_resume.py \
  --progress-every 10 \
  --checkpoint-size 25
```

Script membaca CSV lokal dan hanya menjadwalkan tanggal yang belum tersimpan.

## Checkpoint

Default `--checkpoint-size 25` berarti setiap maksimal 25 tanggal request, hasil sukses/empty langsung ditulis ke file tahun terkait. Jika proses crash, run berikutnya melanjutkan dari tanggal yang belum tersimpan.

## Catatan

Default `--refresh-days 0`, sehingga tanggal yang sudah ada tidak ditarik ulang. Gunakan `--refresh-days N` hanya bila memang ingin refresh N hari terbaru.
